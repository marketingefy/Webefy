# Skills de EFY para el nuevo repositorio

Paquete preparado el 9 de octubre de 2026, America/Guayaquil.

Contiene las 27 skills personales completas de este entorno, las cinco copias
vendorizadas de EFY y cuatro skills de documentos del host, con sus referencias,
scripts, datos, recursos y licencias existentes. `CATALOGO.json` identifica cada
copia y `SHA256.json` permite comprobar todos los archivos.

Incluye también copias documentales de las dos skills del catálogo cloud. La
de onboarding lleva su referencia disponible. La de comparar seguros es parcial:
su SKILL.md remite a tres archivos que el proveedor no entrega en esta sesión.
Se conserva como referencia y no se instala automáticamente como completa.

## Instalación en el otro repositorio

Descomprime el ZIP en una carpeta de herramientas separada del código de la web.
Desde esa carpeta, sustituye `/ruta/nuevo-repositorio` por el checkout existente:

```bash
python3 instalar.py --verify-only
python3 instalar.py --repo /ruta/nuevo-repositorio --destino ambos --dry-run
python3 instalar.py --repo /ruta/nuevo-repositorio --destino ambos
```

Para Codex se usa `.agents/skills/`; para Claude, `.claude/skills/`. Puedes elegir
`--destino codex` o `--destino claude`. La instalación estándar activa 31 skills
únicas: las 27 personales y las cuatro adicionales del repositorio. Las dos
copias de frontend-design permanecen en el ZIP, pero sólo se instala una para
evitar nombres duplicados. `--frontend-source repo` elige la vendorizada.

El instalador verifica los hashes, conserva archivos existentes y se detiene
antes de instalar si encuentra un destino diferente. Si ya está instalado con
los mismos archivos, no vuelve a copiarlos. No descarga paquetes, modifica
dependencias de la web, configura cuentas, ejecuta código de las skills ni
publica ningún sitio. Conserva los permisos de los scripts en sistemas POSIX.

Las cuatro skills de documentos se añaden con `--include-host-skills` cuando el
nuevo host soporte sus herramientas. Si ya son nativas del otro chat, usa esas
copias nativas. Copiar instrucciones no instala artifact_tool, renderizadores,
servicios Google ni herramientas privadas del producto.

Después abre una tarea nueva para que se descubran las skills. El otro agente
debe comprobar cuáles aparecen; si el host no las descubre, puede leer los
SKILL.md completos directamente. No prometemos activación automática en todos
los productos por el solo hecho de copiar archivos.

## Para construir la página pública de EFY

Leer primero `GUIA-MARCA-EFY.md`: incluye los códigos exactos de marca, contraste,
tipografía, uso del logotipo, interacción, móvil y criterios para una web pública.
`referencias-efy/tokens-efy.css` ofrece tokens CSS opcionales, delimitados por
`data-efy-theme="graphite"`; no impone estilos globales ni instala fuentes.
La guía distingue los valores confirmados de las propuestas para la nueva web.

Comenzar por frontend-design, Impeccable, EFY Visual, React Best Practices y
Playwright según el trabajo. Las demás quedan disponibles sin activar todos los
procedimientos al mismo tiempo. HyperFrames se usa para vídeos cuando haga falta.

`referencias-efy/DESIGN-CRM.md` es la fuente visual actual del CRM: cristal grafito,
magenta y azul de marca, foco visible, móvil, contraste y movimiento reducido.
Los textos históricos de efy-analyzer-visual se conservan sin reescribirlos;
algunos describen el diseño anterior. Ante discrepancias, usar la identidad
vigente y el brief de la página pública. Adaptar composición a su audiencia.

Las rutas Mac, el dominio app.latamyanez.com, el reparto de roles con Claude y
los procedimientos del CRM son contexto de ese producto. No trasladar su hosting,
datos, login Evia, permisos, versiones o configuración a la web nueva. Aplicar las
instrucciones del nuevo repositorio y el alcance autorizado por el propietario.
Resolver las referencias locales respecto de la carpeta de cada skill.

## Herramientas, plugins y conexiones

`RUNTIMES-OPCIONALES.md` explica los manifiestos separados de HyperFrames,
Playwright CLI y AnimateIcons incluidos aquí. Son herramientas, no skills.
Los node_modules, binarios, navegadores y cachés no se transportan en el ZIP.

`CONEXIONES.md` enumera lo que el nuevo chat debe comprobar o conectar aparte.
No incluye secretos, .env, sesiones, cookies, archivos de autenticación ni una
copia del MCP configurado del CRM. Los plugins no se instalan copiando una skill.

Para entregar este paquete al otro chat, adjunta el ZIP y pega el texto de
`MENSAJE-PARA-EL-OTRO-CHAT.txt`. La prueba de instalación de este archivo se hizo
en carpetas temporales, sin modificar EFY ni un nuevo repositorio real.
