# Conexiones para el nuevo chat

Las siguientes capacidades se configuran en el host o en los ajustes seguros del
nuevo entorno. Este archivo transfiere nombres y contexto, nunca valores.

| Capacidad | Qué comprobar en el nuevo chat |
| --- | --- |
| GitHub | Conectar el nuevo repositorio y verificar lectura; comprobar escritura cuando vaya a entregar cambios. Reutilizar autenticación inyectada antes de solicitar un token. |
| Context7 | Buscar su herramienta y resolver una biblioteca antes de consultar documentación. La configuración y disponibilidad se verifican en el nuevo host. |
| Vercel | Seleccionar el proyecto de la página web, con su dominio. La conexión del CRM no demuestra permisos ni configuración de ese proyecto. Binding posible: VERCEL_TOKEN. |
| Resend | Sólo si la web enviará correos: binding RESEND_API_KEY y remitente autorizado. No enviar correos reales para probar diseño. |
| Supabase | Sólo si la web necesita persistencia, autenticación o una auditoría de BD. Verificar el proyecto correcto. Nombres habituales: NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY y, exclusivamente en servidor, SUPABASE_SECRET_KEY. |
| Higgsfield / Adobe / Canva | Instalar o activar su plugin en el nuevo host y conectar la cuenta si se va a producir material. Las skills locales no transfieren OAuth ni créditos. |
| Lark | Opcional. Claude mantiene esa conexión del CRM según el acuerdo anterior. No es requisito para diseñar la página pública. |
| Gemini / Anthropic / Push | Integraciones opcionales del producto. Se habilitan sólo si la nueva web requiere esas funciones, con secretos seguros del nuevo proyecto. |
| Pages / Sites / Pets / Computer use | Capacidades del producto anfitrión; no se reproducen con carpetas de skills. No cambiar el hosting de EFY automáticamente. |
| PDF / documentos / presentaciones / hojas | Cuatro carpetas del host exportadas completas. Algunas operaciones necesitan su runtime y herramientas del producto. |
| code-review-graph | No se dispone de una fuente y versión portable verificadas. No se incluye un sustituto inventado. |

Las comprobaciones de servicios que se hicieron en el chat del CRM no certifican
la autenticación del nuevo chat. No se conecta, gasta créditos, envía correos ni
despliega por ejecutar instalar.py. El nuevo agente puede iniciar diseño y revisión
de fuente con las skills mientras configura sólo los servicios pertinentes.

Las skills del sistema como imagegen, openai-docs, skill-creator o skill-installer
se comprueban en el catálogo del nuevo host. Sus carpetas originales no están
disponibles aquí; este ZIP no inventa copias ni incluye instaladores de plugins.
