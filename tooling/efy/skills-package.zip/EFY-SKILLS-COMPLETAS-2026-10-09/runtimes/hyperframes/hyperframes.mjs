#!/usr/bin/env node
import { fileURLToPath, pathToFileURL } from "node:url";
import { dirname, join } from "node:path";
import { createRequire } from "node:module";
import { existsSync } from "node:fs";
import { homedir } from "node:os";

// Keep this isolated installation deliberate: no telemetry, automatic upgrades,
// or optional dependency installs. The caller's working directory is preserved.
process.env.HYPERFRAMES_NO_TELEMETRY = "1";
process.env.DO_NOT_TRACK = "1";
process.env.HYPERFRAMES_NO_UPDATE_CHECK = "1";
process.env.HYPERFRAMES_NO_AUTO_INSTALL = "1";

const toolingDirectory = dirname(fileURLToPath(import.meta.url));
const requireRuntime = createRequire(join(toolingDirectory, "runtime", "package.json"));
process.env.HYPERFRAMES_FFMPEG_PATH ??= requireRuntime("ffmpeg-static");
process.env.HYPERFRAMES_FFPROBE_PATH ??= requireRuntime("@derhuerst/ffprobe-static");

// Reuse the existing Playwright browser rather than downloading another copy.
const existingBrowser = join(homedir(), "Library", "Caches", "ms-playwright", "chromium_headless_shell-1237", "chrome-headless-shell-mac-arm64", "chrome-headless-shell");
if (!process.env.HYPERFRAMES_BROWSER_PATH && existsSync(existingBrowser)) {
  process.env.HYPERFRAMES_BROWSER_PATH = existingBrowser;
}
const cliPath = join(toolingDirectory, "runtime", "node_modules", "hyperframes", "bin", "hyperframes.mjs");
await import(pathToFileURL(cliPath).href);
