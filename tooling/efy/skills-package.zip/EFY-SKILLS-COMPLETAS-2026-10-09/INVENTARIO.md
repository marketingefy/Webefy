# Inventario del paquete

9 de octubre de 2026 · America/Guayaquil.

36 carpetas completas: 27 personales, cinco del repositorio y cuatro del host.
Las dos copias de frontend-design se conservan; el instalador elige una.
La instalación estándar añade31 skills únicas por producto. Con las cuatro del host,35.

| Grupo | Carpeta original | Nombre declarado | Archivos |
| --- | --- | --- | --- |
| personales | animation-vocabulary | animation-vocabulary | 1 |
| personales | apple-design | apple-design | 1 |
| personales | efy-analyzer-visual | efy-analyzer-visual | 7 |
| personales | emil-design-eng | emil-design-eng | 1 |
| personales | find-animation-opportunities | find-animation-opportunities | 1 |
| personales | frontend-design | frontend-design | 2 |
| personales | hyperframes | hyperframes | 29 |
| personales | hyperframes-animation | hyperframes-animation | 122 |
| personales | hyperframes-audio | hyperframes-audio | 7 |
| personales | hyperframes-cli | hyperframes-cli | 11 |
| personales | hyperframes-core | hyperframes-core | 11 |
| personales | hyperframes-creative | hyperframes-creative | 79 |
| personales | hyperframes-keyframes | hyperframes-keyframes | 3 |
| personales | hyperframes-registry | hyperframes-registry | 12 |
| personales | hyperframes-studio | hyperframes-studio | 1 |
| personales | impeccable | impeccable | 152 |
| personales | improve-animations | improve-animations | 3 |
| personales | media-use | media-use | 104 |
| personales | playwright | playwright | 9 |
| personales | playwright-cli | playwright-cli | 10 |
| personales | react-best-practices | vercel-react-best-practices | 76 |
| personales | review-animations | review-animations | 2 |
| personales | screenshot | screenshot | 11 |
| personales | taste-skill | design-taste-frontend | 1 |
| personales | ui-ux-pro-max | ui-ux-pro-max | 44 |
| personales | vercel-deploy | vercel-deploy | 6 |
| personales | web-design-guidelines | web-design-guidelines | 1 |
| repositorio | diagnosing-bugs | diagnosing-bugs | 2 |
| repositorio | frontend-design | frontend-design | 2 |
| repositorio | grill-me | grill-me | 2 |
| repositorio | grilling | grilling | 2 |
| repositorio | resolving-merge-conflicts | resolving-merge-conflicts | 2 |
| host | documents | documents | 78 |
| host | pdf | pdf | 4 |
| host | presentations | Presentations | 59 |
| host | spreadsheets | Spreadsheets | 19 |

## Procedencia

- Personales originales: copia completa transferida desde el ZIP autorizado del propietario; no se inventa una URL o revisión de instalación.
- Diez HyperFrames: heygen-com/hyperframes, revisión438ea9d59fd5c1e720cc55311150dd3b25fab3db registrada en la instalación.
- Frontend vendorizado: anthropics/skills; las otras cuatro de .claude/skills: mattpocock/skills, según la documentación del CRM. Las licencias existentes se conservan.
- Documentos del host: carpetas efectivamente presentes, sin afirmar compatibilidad ni activar herramientas del producto en otro host.

## Copias documentales de nube

- cloud-environment-onboarding:setup: SKILL.md y references/onboarding.md. Su herramienta de configuración pertenece al producto anfitrión.
- comparar-cotizaciones-seguros: sólo SKILL.md, parcial. Se intentó leer cada uno de sus tres recursos auxiliares; el proveedor no los entregó. No se inventan ni se instala esta copia como completa.

## Contenido excluido

node_modules, .git, __pycache__, cachés, navegadores/binarios, .env, autenticación, cookies y configuración de cuentas. No son recursos de skill portables. No se copió el código del CRM ni su configuración MCP.
