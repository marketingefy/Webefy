---
name: comparar-cotizaciones-seguros
description: Comparar una póliza, plan vigente, tarifas históricas o cuadro mandatorio contra una o varias cotizaciones de seguros y producir un informe ejecutivo HTML con equivalencias, brechas, ranking, variaciones de precio, alertas y condiciones de negociación. Usar cuando el usuario adjunte o pegue propuestas, pólizas, precios anteriores, condiciones, cuadros de beneficios, PDFs, Excel, imágenes o texto de cualquier ramo y pida homologar coberturas y costos, identificar la alternativa más parecida, preparar un comparativo para clientes o aseguradoras, o repetir el formato de análisis técnico de EFY Seguros.
---

# Comparar cotizaciones de seguros

Producir un comparativo defendible y comercialmente útil. Basar cada conclusión en texto expreso de las fuentes; no asumir beneficios por prácticas de mercado ni por el nombre del producto.

## Flujo obligatorio

1. Inventariar todos los archivos y textos recibidos.
2. Separar la línea base vigente o mandatoria de las nuevas ofertas.
3. Extraer condiciones con trazabilidad de página, hoja, fila o sección.
4. Incorporar los precios anteriores como referencia mandatoria cuando estén disponibles.
5. Normalizar conceptos antes de compararlos.
6. Calificar equivalencias, brechas y variaciones tarifarias.
7. Seleccionar la configuración más cercana de cada oferente.
8. Emitir una recomendación condicionada y una estrategia de negociación.
9. Crear, validar y entregar un HTML ejecutivo.

## 1. Revisar las fuentes

- Usar la habilidad de PDF para renderizar e inspeccionar visualmente los PDFs, además de extraer texto.
- Usar la habilidad de hojas de cálculo para revisar libros Excel, incluidas hojas ocultas, fórmulas, notas, filas y variantes de plan.
- Aplicar OCR o revisión visual a imágenes y páginas escaneadas.
- Tratar el texto escrito por el usuario como fuente válida de la línea base; identificarlo como “condiciones comunicadas por el usuario”.
- Detectar diferencias de censo, fecha, vigencia, impuestos, prima neta/total y moneda.
- Extraer tarifas anteriores por modalidad o categoría, incluso cuando se entreguen como imagen.
- No detener el análisis por falta de sábana de siniestralidad. Registrar la limitación y condicionar tarifas o aceptación cuando corresponda.

Leer [references/comparison-framework.md](references/comparison-framework.md) para el esquema de extracción y las reglas de equivalencia.

## 2. Definir la línea base

Construir primero un “Plan Base - Mandatorio” con todos los requisitos proporcionados. Distinguir claramente:

- cobertura principal;
- sublímites;
- porcentaje y modalidad;
- red o libre elección;
- deducible, copago y coaseguro;
- valores agregados fuera de cobertura;
- tarifas o primas anteriores por modalidad;
- condiciones operativas y de suscripción.

Tratar las tarifas históricas proporcionadas por el usuario como objetivo económico del plan. No asumir una tolerancia máxima de incremento si el usuario no la ha definido.

Si no existe una línea base identificable, solicitar una sola aclaración breve. Si el usuario pide comparar únicamente las ofertas, usar como referencia la opción más completa y declararlo.

## 3. Normalizar sin crear falsas equivalencias

- Distinguir monto anual, por evento, por enfermedad, por incapacidad y por vigencia.
- Distinguir crédito, reembolso, red cerrada, red abierta, libre elección y prestadores direccionados.
- Comparar porcentajes junto con deducible, copago, tarifario y red; nunca aisladamente.
- Separar vida, exequias, accidentes personales, asistencia en viaje y gastos médicos en el exterior.
- Separar maternidad general, parto, cesárea, aborto no provocado, legrado y complicaciones.
- Marcar “no consta” cuando el documento sea silencioso. No convertir silencio en exclusión ni en cobertura.
- Marcar “requiere confirmación” cuando el concepto sea parecido pero no idéntico.

## 4. Comparar precios históricos

- Comparar cada categoría contra su tarifa anterior usando diferencia absoluta y porcentual.
- Homologar prima neta con prima neta y prima total con prima total. Señalar cualquier base no comparable.
- No calcular el impacto total mensual o anual sin conocer el número de afiliados por modalidad.
- Solicitar o registrar como pendiente la distribución del censo cuando falte.
- Identificar la categoría que concentra el mayor incremento.
- Mostrar alternativas de precio cercano aunque tengan cobertura insuficiente, pero etiquetarlas claramente como no equivalentes.
- Priorizar en la recomendación el equilibrio entre cumplimiento mandatorio y precio anterior. No recomendar una alternativa sustancialmente más cara sin advertirlo al inicio.
- Proponer una meta de negociación por categoría o un presupuesto global ponderado cuando exista el censo.

## 5. Calificar cada condición

Usar cuatro estados:

- `Cumple / mejora`: iguala o supera sin añadir una restricción material.
- `Cumplimiento parcial`: mejora una dimensión, pero cambia modalidad, red, deducible, sublímite, definición o alcance.
- `Brecha`: queda por debajo o falta una condición mandatoria.
- `No verificable`: la fuente no contiene información suficiente.

No usar un porcentaje de similitud opaco. Si se presenta un ranking, justificarlo por cantidad y criticidad de condiciones. Tratar precio y coberturas expresamente declarados como mandatorios; explicar cualquier compensación entre ambos.

## 6. Seleccionar y recomendar

- Comparar una configuración representativa por oferente en la matriz principal.
- Explicar variantes relevantes cuando otro plan del mismo oferente resuelva una brecha pero cree otra.
- Declarar expresamente si ninguna oferta replica el programa.
- Recomendar la alternativa más cercana como base de negociación, no como cumplimiento definitivo, cuando existan brechas.
- Convertir cada brecha crítica en una solicitud de endoso, aclaratorio o carta de aceptación.
- Incluir una opción compuesta cuando sea más eficiente contratar salud y completar vida, viaje o valores agregados por separado.
- Mantener separadas la “mejor opción integral” y la “opción más cercana solo en precio” cuando no coincidan.

## 7. Crear el HTML

Usar [assets/executive-report-template.html](assets/executive-report-template.html) como punto de partida o reproducir su sistema visual cuando el contenido requiera otra estructura.

Incluir siempre:

1. Portada con cliente, fecha y alcance.
2. Conclusión ejecutiva al inicio.
3. Línea base mandatoria en tarjetas.
4. Ranking razonado de alternativas.
5. Matriz de equivalencia con estados, notas y fuentes.
6. Comparativo de tarifas históricas y nuevas con diferencia absoluta y porcentual por categoría.
7. Condiciones concretas para negociación.
8. Alertas de suscripción, continuidad, carencias, preexistencias y definiciones.
9. Fuentes revisadas y limitaciones.

Aplicar estas reglas de diseño:

- Crear un archivo autocontenido, sin dependencias externas.
- Usar HTML semántico, diseño responsive y CSS de impresión.
- Mantener la primera columna visible en matrices anchas.
- Usar colores accesibles y texto adicional; no comunicar estados únicamente por color.
- Mantener precisión documental con referencias del tipo `archivo, p. 3` o `Excel, hoja Coberturas, filas 12-18`.
- Usar fechas absolutas y formato monetario consistente.
- Evitar lenguaje confrontativo. Redactar con criterio técnico, comercial y negociador.

## 8. Validar

Ejecutar:

```bash
python3 scripts/validate_comparison_html.py /ruta/al/informe.html
```

Corregir cualquier marcador pendiente, sección faltante, tabla vacía o ausencia de fuentes. Abrir o renderizar el HTML cuando exista un navegador local; realizar al menos validación estructural cuando no exista.

Revisar además:

- que la alternativa recomendada coincida con la matriz;
- que ninguna cifra se haya tomado de otra variante del mismo oferente;
- que las tarifas indiquen si incluyen impuestos;
- que cada tarifa nueva muestre la variación frente a la anterior cuando exista esa referencia;
- que no se calcule presupuesto total sin la distribución del censo;
- que la conclusión identifique la categoría con mayor desviación tarifaria;
- que el censo de cada propuesta esté identificado;
- que los límites y porcentajes conserven su modalidad;
- que “no consta” no se redacte como “no cubre”.

## 9. Entregar

Guardar el HTML como artefacto persistente según las reglas del entorno. Entregar un enlace al archivo y resumir en pocas líneas: alternativa más cercana, brechas críticas y acción recomendada.

