#!/usr/bin/env python3
"""Instala copias verificadas de skills por repositorio, sin red ni sobrescrituras."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def segura(base, relativa):
    p = PurePosixPath(relativa)
    if p.is_absolute() or not p.parts or any(x in ('.', '..') for x in p.parts):
        raise ValueError('Ruta no válida en el paquete: ' + relativa)
    ruta = base.joinpath(*p.parts)
    for padre in (ruta, *ruta.parents):
        if padre == base:
            break
        if padre.is_symlink():
            raise ValueError('No se admiten enlaces simbólicos: ' + relativa)
    if not ruta.resolve().is_relative_to(base.resolve()):
        raise ValueError('Ruta fuera del paquete: ' + relativa)
    return ruta


def huella(ruta):
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


def verificar():
    manifest = json.loads((ROOT / 'SHA256.json').read_text(encoding='utf-8'))
    for relativa, info in manifest['files'].items():
        ruta = segura(ROOT, relativa)
        if not ruta.is_file() or ruta.stat().st_size != info['bytes'] or huella(ruta) != info['sha256']:
            raise ValueError('Falta un archivo o no coincide su SHA256: ' + relativa)
    catalogo = json.loads((ROOT / 'CATALOGO.json').read_text(encoding='utf-8'))
    for skill in catalogo['skills']:
        fuente = segura(ROOT, skill['source'])
        real = {p.relative_to(ROOT).as_posix() for p in fuente.rglob('*') if p.is_file()}
        if real != set(skill['files']):
            raise ValueError('La carpeta contiene archivos distintos del catálogo: ' + skill['id'])
        if any(p.is_symlink() for p in fuente.rglob('*')):
            raise ValueError('La carpeta contiene enlaces simbólicos: ' + skill['id'])
        if not re.fullmatch(r'[a-z0-9][a-z0-9_-]*', skill['name']):
            raise ValueError('Nombre de instalación no válido: ' + skill['id'])
    return manifest, catalogo


def coincide(origen, destino):
    if not destino.is_dir() or destino.is_symlink():
        return False
    if any(p.is_symlink() for p in destino.rglob('*')):
        return False
    a = {p.relative_to(origen).as_posix(): huella(p) for p in origen.rglob('*') if p.is_file()}
    b = {p.relative_to(destino).as_posix(): huella(p) for p in destino.rglob('*') if p.is_file()}
    return a == b


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, help='Carpeta existente del nuevo repositorio')
    parser.add_argument('--destino', choices=['codex', 'claude', 'ambos'], default='ambos')
    parser.add_argument('--include-host-skills', action='store_true', help='Añadir las cuatro skills del host; sus herramientas requieren configuración aparte')
    parser.add_argument('--frontend-source', choices=['personal', 'repo'], default='personal', help='Elegir una de las dos copias originales de frontend-design')
    parser.add_argument('--dry-run', action='store_true', help='Verificar y mostrar sin escribir en el repositorio')
    parser.add_argument('--verify-only', action='store_true', help='Verificar integridad del paquete sin instalar')
    args = parser.parse_args()
    manifest, catalogo = verificar()
    print(f"Integridad correcta: {len(manifest['files'])} archivos verificados.")
    if args.verify_only:
        return
    if args.repo is None or not args.repo.is_dir():
        parser.error('--repo debe señalar una carpeta existente')
    repo = args.repo.resolve()
    elegidas = [s for s in catalogo['skills'] if s['group'] == 'personales' or (s['group'] == 'repositorio' and s['name'] != 'frontend-design')]
    if args.frontend_source == 'repo':
        elegidas = [s for s in elegidas if s['name'] != 'frontend-design']
        elegidas += [s for s in catalogo['skills'] if s['group'] == 'repositorio' and s['name'] == 'frontend-design']
    if args.include_host_skills:
        elegidas += [s for s in catalogo['skills'] if s['group'] == 'host']
    assert len({s['name'] for s in elegidas}) == len(elegidas)
    plataformas = ['.agents/skills', '.claude/skills'] if args.destino == 'ambos' else ['.agents/skills' if args.destino == 'codex' else '.claude/skills']
    pendientes = []
    conflictos = []
    existentes = 0
    for prefijo in plataformas:
        for skill in elegidas:
            relativa = prefijo + '/' + skill['name']
            destino = segura(repo, relativa)
            for padre in destino.parents:
                if padre == repo:
                    break
                if padre.exists() and not padre.is_dir():
                    conflictos.append(str(padre))
            fuente = segura(ROOT, skill['source'])
            if destino.exists():
                if coincide(fuente, destino):
                    existentes += 1
                else:
                    conflictos.append(str(destino))
            else:
                pendientes.append((skill, fuente, destino))
    if conflictos:
        raise ValueError('No se instaló nada. Hay archivos existentes distintos; consérvalos y revisa estos destinos:\n' + '\n'.join(sorted(set(conflictos))))
    print(f"Skills únicas seleccionadas: {len(elegidas)}; copias nuevas: {len(pendientes)}; idénticas existentes: {existentes}.")
    if args.dry_run:
        for skill, _, destino in pendientes:
            print(f"PREVISTO {skill['id']} -> {destino}")
        return
    for skill, fuente, destino in pendientes:
        destino.parent.mkdir(parents=True, exist_ok=True)
        temporal = Path(tempfile.mkdtemp(prefix='.efy-skill-', dir=destino.parent))
        try:
            staged = temporal / 'contenido'
            shutil.copytree(fuente, staged)
            for relativa in skill['files']:
                archivo = staged / Path(relativa).relative_to(skill['source'])
                if os.name != 'nt':
                    archivo.chmod(manifest['files'][relativa]['mode'])
            if destino.exists():
                raise ValueError('El destino cambió durante la instalación: ' + str(destino))
            staged.rename(destino)
        finally:
            shutil.rmtree(temporal)
        print('INSTALADA ' + str(destino))
    print('Instalación completa. Abre una tarea nueva y comprueba el catálogo; los runtimes y conexiones se configuran aparte.')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, AssertionError, KeyError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(2)
