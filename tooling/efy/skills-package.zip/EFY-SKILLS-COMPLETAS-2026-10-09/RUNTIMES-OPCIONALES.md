# Runtimes independientes

Estas carpetas contienen manifiestos y locks de herramientas instaladas en este
entorno, separados de las dependencias del CRM. No se ejecutan al instalar skills.
Reconstruirlos sólo si la tarea nueva necesita esas herramientas, comprobando
SO, arquitectura, Node y navegador del nuevo entorno.

## HyperFrames

`runtimes/hyperframes/runtime/` fija CLI0.8.113, ffmpeg-static5.3.0 y
@derhuerst/ffprobe-static5.3.0. Es el lock Linux verificado durante la migración
del6 de octubre, no el lock Mac pegado que tenía discrepancias. Las diez skills
de HyperFrames proceden de heygen-com/hyperframes, SHA
438ea9d59fd5c1e720cc55311150dd3b25fab3db, Apache-2.0.

Node debe satisfacer el lock, incluidas dependencias que requieren >=22.12.0.
Comprobar primero los scripts de instalación y los requisitos del nuevo host:

```bash
cd runtimes/hyperframes/runtime
npm ci --ignore-scripts
npm rebuild ffmpeg-static @derhuerst/ffprobe-static
```

Las descargas de binarios mantienen TLS e integridades. El lanzador original
`runtimes/hyperframes/hyperframes.mjs` desactiva telemetría, actualizaciones e
instalación opcional automática. Elegir un navegador compatible e indicar
HYPERFRAMES_BROWSER_PATH; no reutilizar una caché Mac ARM en Linux. Usar el
lanzador desde un proyecto de vídeo separado, que no cargue el .env de la web:

```bash
HYPERFRAMES_BROWSER_PATH=/ruta/al/navegador node /ruta/al/paquete/runtimes/hyperframes/hyperframes.mjs --version
HYPERFRAMES_BROWSER_PATH=/ruta/al/navegador node /ruta/al/paquete/runtimes/hyperframes/hyperframes.mjs --help
HYPERFRAMES_BROWSER_PATH=/ruta/al/navegador node /ruta/al/paquete/runtimes/hyperframes/hyperframes.mjs doctor --json
```

Las comprobaciones antiguas del CRM no prueban el runtime del nuevo repositorio.
Revalidar binarios y, si se necesita render, una muestra real. Whisper, Kokoro y
MusicGen son opcionales y no están incluidos. No descargar modelos ni consumir
servicios de pago por el solo hecho de instalar las instrucciones.

## Playwright CLI

`runtimes/playwright/` fija @playwright/cli0.1.22. Reconstruir con npm ci desde su
lock y seleccionar el navegador adecuado al host; no copiar cookies o sesiones.
La copia de Playwright dentro de la nueva web puede tener otra versión fijada:
respetar su manifiesto y sus scripts de QA. Las skills usan referencias históricas
de wrappers; adaptar las rutas al runtime realmente instalado.

## AnimateIcons

`runtimes/animateicons/` fija @animateicons/react0.6.0 con React18.3.1 en un
workbench aislado. Procedencia: Avijit07x/animateicons, MIT. Es una biblioteca,
no una conexión ni una skill. Su existencia no demuestra integración en la web.
Revisar la compatibilidad con el React del nuevo proyecto antes de integrarla;
no sustituir el package.json o lock de la web por estos manifiestos.
