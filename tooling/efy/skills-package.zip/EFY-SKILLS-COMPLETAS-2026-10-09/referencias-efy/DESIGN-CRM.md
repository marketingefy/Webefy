# Sistema visual de EfyAnalyzer

Este documento define la capa visual del CRM de Efy Seguros. No modifica ni
reemplaza las reglas funcionales del producto descritas en `PRODUCT.md`.

## Dirección

EfyAnalyzer debe sentirse tecnológico, seguro y humano. La idea rectora es una
“óptica de confianza”: navegación oscura y contenida, un lienzo topográfico
profundo, superficies operativas de vidrio grafito, datos densos bien ordenados
y señales de color precisas. La textura une login, navegación, CRM y portal.
El magenta ilumina el fondo como una señal de energía y el azul construye
profundidad; ambos permanecen detrás de la información y nunca compiten con ella.

## Marca

- Magenta principal: `#EC245B`
- Magenta profundo: `#C61649`
- Azul eléctrico: `#445EA5`
- Azul profundo: `#344B88`
- Tinta: `#0B1020`
- Tinta secundaria: `#17233D`
- Lienzo: `#F7F8FB`
- Línea: `#DFE4EC`

La marca usa exclusivamente los artes oficiales de `public/brand`: versiones
horizontal, vertical y símbolo con sello IA, tanto en color como en blanco.
No deben redibujarse, deformarse ni sustituirse por una llama genérica. El menú
usa el símbolo oficial magenta/azul junto al nombre oficial blanco, sin placa
de fondo; el ingreso y las cabeceras oscuras usan el arte completamente blanco.
La espera de Evia usa la variante del menú —símbolo magenta/azul y nombre
blanco— sobre el fondo topográfico reforzado con luz magenta.
Favicon e iconos instalables usan el símbolo color sobre fondo blanco opaco.
El sello `IA ✦` se amplía únicamente en estos tamaños reducidos —sin redibujar
la llama ni el sello— para que la propuesta de inteligencia artificial siga
siendo visible en el inicio del teléfono y en el lanzador del computador. La
variante maskable conserva todo el conjunto dentro de la zona segura Android.

## Tipografía

- Títulos y cifras principales: Nunito Sans, pesos 600–800.
- Interfaz y lectura: IBM Plex Sans, pesos 400–600.
- Cédulas, montos y datos tabulares: IBM Plex Mono.

Los títulos son directos; no llevan una etiqueta pequeña encima. La jerarquía
se expresa con tamaño, peso, espacio y una señal breve magenta/azul.

## Superficies y composición

- Radio de superficie: 14 px.
- Las superficies operativas usan gris grafito translúcido, texto claro, una
  luz interior superior y sombras frías en dos niveles para crear profundidad
  3D sin parecer objetos flotantes independientes.
- Los indicadores forman una banda continua dividida por líneas, no una
  colección de tarjetas idénticas.
- Los filtros viven en superficies discretas y compactas.
- El fondo topográfico y las luces magenta/azul forman una sola capa estática
  dimensionada por la pantalla, independiente del alto de la página. Una
  lista de cientos de registros debe mostrar el mismo material que una ficha
  corta; no escalar el arte con el alto de toda la lista. Esta regla se
  comparte entre CRM y portal, sin intervenir en el ingreso.
- Los diálogos y cajones usan el token de vidrio denso
  `--efy-liquid-dialog-material`: transparencia y desenfoque en el panel, no
  texto de otra ventana legible detrás. Las cabeceras de marca usan
  `efy-glass-highlight`, sin gradientes hexadecimales opacos por pantalla.
- Las listas de registros usan `interactive-row` cuando la fila completa abre
  una ficha, y `efy-fila-fija` cuando contiene campos o acciones independientes.
  Ambas comparten vidrio grafito, reflejo superior y transparencia sin
  desenfoque por fila. Los accesos `.surface` y los paneles conservan su vidrio.
- El resaltado azul de Emisiones es la respuesta compartida al pasar el cursor
  y al enfocar una fila accionable. Los botones de subfilas, cifras pulsables y
  cabeceras de acordeón usan `efy-row-action`; las filas fijas no se desplazan.
  Las alertas mantienen su color y señalan el foco con un borde azul. En táctil
  no se activa un hover persistente; una superficie de lectura no simula clic.
- La navegación y el contenido comparten el mundo oscuro; inputs, tablas,
  diálogos y tooltips conservan contraste alto dentro del mismo material.
- Las métricas vencidas usan cristal rojo-magenta profundo y texto blanco. El
  estado conserva su rótulo e icono para no depender solamente del color.
- La ruta activa del menú lleva una señal vertical magenta dentro del material,
  tanto en el módulo como en su pantalla seleccionada.
- El portal de clientes comparte la marca, pero usa más aire y menos densidad
  que la operación interna.
- Estados y prioridades se representan con puntos, badges y color semántico;
  no con bordes laterales gruesos.
- Las insignias amarillas claras conservan texto ámbar oscuro (`text-amber-800`
  o `text-amber-900`); nunca heredan el ámbar claro del lienzo grafito. Los
  avisos claros con contenido mixto usan `efy-light-alert-surface`, también en
  módulos nuevos: sus etiquetas y errores son oscuros, sus `.input` mantienen
  su fondo y tipografía propios. Verificar al menos 4,5:1 de contraste.

## Dashboards y estadísticas

- Las superficies de análisis usan un vidrio grafito más mate y discreto que
  los formularios, pero nunca placas grises opacas: conservan transparencia,
  una luz interior superior y desenfoque contenido. Las listas largas pueden
  omitir el desenfoque por fila para mantener el desplazamiento fluido.
- Las proporciones con un total conocido se muestran en anillos circulares,
  siempre acompañados de rótulos y cifras. Las comparaciones y series usan
  barras con extremos ovalados; las tendencias temporales conservan sus líneas.
- El color cambia con el significado del dato: azul para actividad, verde para
  resultados favorables, magenta/rojo para alertas y ámbar para atención.
  Nunca es la única señal de estado.
- En las barras comparativas, el volumen usa violeta, el avance magenta y la
  alerta rojo coral para armonizar con el fondo de marca; rótulos y cifras
  mantienen la distinción incluso sin percibir el color.
- Las métricas por persona pueden usar la foto del perfil ya disponible, con
  iniciales como alternativa. No se piden datos nuevos sólo para decorar.
- No se usan columnas facetadas o extruidas en las analíticas: el volumen lo
  aportan el contraste, la composición y el fondo de la aplicación.

## Movimiento

- Interacciones: 160–220 ms.
- Entradas de página y métricas: 220–250 ms.
- Revelado de la llama de datos: hasta 700 ms, una sola vez.
- Curva principal: `cubic-bezier(0.16, 1, 0.3, 1)`.
- Animar preferentemente `transform` y `opacity`.
- Evitar animaciones decorativas infinitas, desenfoques animados y cambios de
  ancho/alto cuando puede usarse una transformación.
- Respetar siempre `prefers-reduced-motion`.

## Acciones y botones

- Toda acción de ficha o formulario usa la familia compartida: `.btn-primary`
  para guardar/confirmar, `.btn-flame` para la llamada principal de marca,
  `.btn-secondary` para editar, renovar, cancelar o pedir ayuda, y
  `.btn-danger` para confirmar una acción destructiva.
- En el CRM, estas acciones tienen silueta ovalada y borde luminoso de vidrio,
  como «Reportar error»; el color diferencia la jerarquía sin cambiar el texto
  ni la función. El ingreso conserva su botón propio.
- En filas densas se usan `.efy-action-quiet`, `.efy-action-warn` o
  `.efy-action-danger` según su significado. Una acción independiente no debe
  quedar como texto plano que parezca una etiqueta.
- Filtros, pestañas, enlaces de retorno e iconos conservan su composición
  propia, pero comparten foco visible, contraste y objetivo táctil adecuado.
- Los filtros de notificaciones que muestran sólo un icono tienen base de
  44 × 44 px y radio de 12 px. El filtro seleccionado puede ampliar su ancho
  para mostrar la etiqueta; conserva el mismo alto y radio.
- La selección de accesos usa `ControlAcceso` y `SelectorModulos`: estado
  textual, interruptor accesible, búsqueda y filtros locales. La presentación
  conserva el borrador y los callbacks de Guardar, Descartar y activación.
- Las demás opciones usan `ControlSeleccion`, conservando el input nativo,
  su etiqueta y sus eventos. Una opción que se activa usa un interruptor;
  elegir varios registros conserva una marca de selección, y una elección
  única conserva el radio. Los tres comparten foco azul y área táctil de 44 px.
- En cada tarjeta de usuario, «Accesos y opciones» nace plegado y resume los
  módulos elegidos. Desplegar o plegar no guarda ni descarta el borrador;
  la barra de Guardar permanece fuera del panel y a la vista.
- Las cuentas de equipo y clientes muestran «Guardar cambios» junto a sus
  accesos, desactivado cuando no hay cambios. Activar un módulo modifica el
  borrador; Guardar confirma y Descartar restaura. `BarraGuardar` comparte
  estados de pendiente, guardando, éxito y error con Finanzas y Comisiones.
- Los tickets en alerta conservan vidrio grafito con señal magenta y rótulo
  explícito. Las notas internas usan un tinte ámbar translúcido con texto claro.
- Las transferencias reutilizan `EstadoArchivo`, `TransferenciasArchivos` y
  `EnlaceDescarga`: icono circular azul, cristal grafito, nombre y fase textual.
  Separar preparación, envío y confirmación; mostrar porcentaje sólo cuando
  existe una medida comprobable, con su unidad. Una descarga nativa muestra
  «Descarga solicitada» sin inventar éxito ni activar «Abrir» por tiempo.
  El movimiento acompaña la actividad, se detiene al terminar y respeta
  movimiento reducido. El aviso móvil deja libre la franja de acciones y no
  se imprime. Mantener enlaces, permisos y recorridos de archivos existentes.
- No se sustituyen etiquetas, orden, permisos, confirmaciones ni funciones de
  clic al aplicar el estilo. Estas reglas también rigen para módulos nuevos.

## Accesibilidad

- El foco visible usa azul eléctrico y contraste suficiente.
- Los controles interactivos mantienen un objetivo táctil cercano a 44 px.
- Ningún estado depende únicamente del color.
- Tablas y cifras conservan números tabulares.
- El orden y los nombres accesibles de la funcionalidad existente no deben
  cambiar por decisiones decorativas.

## Límite de implementación

La capa visual puede modificar composición, tokens, tipografía, espaciado,
iconografía, animaciones, estados visuales y responsive. No puede alterar
rutas, permisos, autenticación, consultas, APIs, Supabase, correos, lógica de
negocio, datos ni infraestructura, salvo una instrucción expresa del
propietario.

## Regla para módulos nuevos

Toda pantalla del CRM y del portal parte de las superficies compartidas
`.card`, `.surface` o `.surface-muted` dentro de `.efy-module-canvas`. Tanto
usuarios como clientes nuevos reciben el mismo material por estos layouts, sin
activarlo por cuenta ni depender de que ya tengan registros. El perfil del
equipo y el del portal reutilizan `PerfilClient` y las mismas superficies.
Los tableros usan `.efy-analytics-board` y los tokens `--efy-liquid-analytics`;
las superficies internas usan `--efy-liquid-inset`. No se introducen fondos
hexadecimales opacos para tarjetas, filtros o filas sólo por tratarse de un
módulo nuevo. La opacidad se reserva para menús, texto o capas que deban
tapar contenido por legibilidad. Antes de dar por terminada una pantalla,
comparar al menos un módulo anterior, revisar 320 px y medir contraste.
La comprobación incluye el fondo realmente pintado, no sólo verificar que el
CSS contenga `rgba`: `scripts/qa/lienzo-cristal.mjs` compara la misma pantalla
con contenido corto/largo, desplazamiento, tarjetas, diálogos e impresión.
Avisos semánticos, insignias, documentos, gráficos y menús que necesiten
ocultar contenido conservan su contraste propio.
